package DriveAPI;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AutomateDriveAPITest extends BaseTest{
	
	@Test
	public void testRatingsFlow() throws InterruptedException {
		startDrive();
		AutomateDriveAPI automateDriveAPI = new AutomateDriveAPI(driver);
		automateDriveAPI.insertParkingLot(1561, "12");
		automateDriveAPI.orderInProgress();
		automateDriveAPI.orderDelivered();
		Assert.assertEquals((automateDriveAPI.checkRatings()).replaceAll("\\r\\n", "\n").trim(),expectedmessage.replaceAll("\\r\\n", "\n").trim());
	}
	
	@Test
	public void testFeedbackFlow() throws InterruptedException
	{
		startDrive();
		AutomateDriveAPI automateDriveAPI = new AutomateDriveAPI(driver);
		automateDriveAPI.insertParkingLot(1562, "10");
		automateDriveAPI.orderInProgress();
		automateDriveAPI.orderDelivered();
		Assert.assertEquals((automateDriveAPI.checkFeedback()).replaceAll("\\r\\n", "\n").trim(),expectedmessage.replaceAll("\\r\\n", "\n").trim());
	}
	
	@Test
	public void skipRatingsPage() throws InterruptedException
	{
		startDrive();
		AutomateDriveAPI automateDriveAPI = new AutomateDriveAPI(driver);
		automateDriveAPI.insertParkingLot(1563, "7");
		automateDriveAPI.orderInProgress();
		automateDriveAPI.orderDelivered();
		Assert.assertEquals((automateDriveAPI.skipRatingsPage()), expecteddeliverymessage);
	}
	
	

}
